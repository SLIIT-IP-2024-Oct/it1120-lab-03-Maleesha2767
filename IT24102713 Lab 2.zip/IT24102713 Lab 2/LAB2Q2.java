public class LAB2Q2
{
     public static void main(String [] args)
{

   int sidelength = 10;
   double perimeter = 4 * 10;

  double radius= 40 / ( 2*3.14);

    System.out.println("Radius of the circular fence: " + radius);
   }
}
