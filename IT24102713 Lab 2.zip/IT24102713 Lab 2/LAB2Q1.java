public class LAB2Q1
{
       public static void main(String[] args)
       {
   
      int perimeter = 100;
       
     double length = (perimeter*2)/7;
     double width = 0.75 * length;


     System.out.println("Length of the fence; " + length);
     System.out.println("Width of the fence; " + width);

    }
}