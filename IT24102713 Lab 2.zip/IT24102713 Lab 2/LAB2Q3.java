public class LAB2Q3
{
    public static void main(String[]args)
   {
        
        double sideA=3;
        double sideB=4;

      double hypotenuse =Math.sqrt((sideA*sideA)+(sideB*sideB));
 
     System.out.println("the length of the hypotenuse is: "+ hypotenuse);
    }
}